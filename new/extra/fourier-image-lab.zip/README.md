# Fourier Image Lab

A dependency-free browser demo that reconstructs a fixed image from a truncated 2D Fourier representation.

## Run it

1. Put your image in this folder (the project root).
2. Open `script.js` and change `IMAGE_SRC` from `./your-image.jpg` to your filename, for example `./logo.png`.
3. Serve this folder with a local static server and open `index.html`. For example, from this folder run `python -m http.server 8000`, then visit `http://localhost:8000`.

Some browsers restrict local image loading from `file://`, so a tiny local static server is the most reliable approach. No packages or build step are needed.

## How it works

- The source image is fitted, without stretching, onto a power-of-two canvas with each dimension at most 256 pixels.
- Each RGB channel is transformed using a pure-JavaScript radix-2 2D FFT.
- The slider keeps the lowest spatial-frequency coefficients first and zeros the rest.
- An inverse FFT produces the current approximation, which is displayed on the result canvas.
- The complete grid has at most 65,536 coefficients. The slider uses a quadratic mapping so the lower term counts are easier to control.

The Fourier expansion is a **trigonometric interpolant**, not an ordinary polynomial in powers of x. With all coefficients retained, the inverse FFT recovers the sampled processing-grid image (up to floating-point rounding). Intermediate reconstructions can show ringing around sharp edges, a normal effect of hard frequency truncation.
