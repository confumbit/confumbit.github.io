'use strict';

/* Replace this with the filename of your image in the project root. */
const IMAGE_SRC = './your-image.jpg';

/*
 * The radix-2 FFT requires power-of-two dimensions. Keeping each dimension
 * at or below 256 gives a maximum grid of 65,536 pixels, which is a practical
 * trade-off for interactive inverse transforms on typical desktop browsers.
 */
const MAX_DIMENSION = 256;
const DIMENSION_CHOICES = [16, 32, 64, 128, 256];
const SLIDER_STEPS = 1000;

const originalCanvas = document.getElementById('originalCanvas');
const resultCanvas = document.getElementById('resultCanvas');
const originalPlaceholder = document.getElementById('originalPlaceholder');
const resultPlaceholder = document.getElementById('resultPlaceholder');
const termsSlider = document.getElementById('termsSlider');
const termsValue = document.getElementById('termsValue');
const termsTotal = document.getElementById('termsTotal');
const termsPercent = document.getElementById('termsPercent');
const gridInfo = document.getElementById('gridInfo');
const renderCaption = document.getElementById('renderCaption');
const statusMessage = document.getElementById('statusMessage');
const resetButton = document.getElementById('resetButton');

let gridWidth = 0;
let gridHeight = 0;
let totalTerms = 0;
let orderedFrequencies = [];
let channelSpectra = [];
let isReady = false;
let renderPending = false;

function setStatus(message, isError = false) {
  statusMessage.textContent = message;
  statusMessage.classList.toggle('error', isError);
}

function nearestGridSize(aspectRatio) {
  let best = null;
  for (const width of DIMENSION_CHOICES) {
    if (width > MAX_DIMENSION) continue;
    for (const height of DIMENSION_CHOICES) {
      if (height > MAX_DIMENSION) continue;
      const error = Math.abs(Math.log((width / height) / aspectRatio));
      const area = width * height;
      if (!best || error < best.error - 1e-10 ||
          (Math.abs(error - best.error) <= 1e-10 && area > best.area)) {
        best = { width, height, error, area };
      }
    }
  }
  return { width: best.width, height: best.height };
}

function makeContainCanvas(image, width, height) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d', { willReadFrequently: true });
  context.fillStyle = '#000000';
  context.fillRect(0, 0, width, height);

  const scale = Math.min(width / image.naturalWidth, height / image.naturalHeight);
  const drawWidth = Math.max(1, Math.round(image.naturalWidth * scale));
  const drawHeight = Math.max(1, Math.round(image.naturalHeight * scale));
  const x = Math.floor((width - drawWidth) / 2);
  const y = Math.floor((height - drawHeight) / 2);
  context.imageSmoothingEnabled = true;
  context.imageSmoothingQuality = 'high';
  context.drawImage(image, x, y, drawWidth, drawHeight);
  return { canvas, context };
}

/* In-place Cooley–Tukey radix-2 FFT. Inverse transforms are normalized by N. */
function fft1d(real, imag, inverse = false) {
  const n = real.length;
  if (n <= 1) return;

  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    while (j & bit) {
      j ^= bit;
      bit >>= 1;
    }
    j ^= bit;
    if (i < j) {
      [real[i], real[j]] = [real[j], real[i]];
      [imag[i], imag[j]] = [imag[j], imag[i]];
    }
  }

  for (let length = 2; length <= n; length <<= 1) {
    const angle = (inverse ? 2 : -2) * Math.PI / length;
    const stepReal = Math.cos(angle);
    const stepImag = Math.sin(angle);
    const half = length >> 1;

    for (let start = 0; start < n; start += length) {
      let weightReal = 1;
      let weightImag = 0;
      for (let j = 0; j < half; j++) {
        const even = start + j;
        const odd = even + half;
        const oddReal = real[odd] * weightReal - imag[odd] * weightImag;
        const oddImag = real[odd] * weightImag + imag[odd] * weightReal;
        const evenReal = real[even];
        const evenImag = imag[even];

        real[even] = evenReal + oddReal;
        imag[even] = evenImag + oddImag;
        real[odd] = evenReal - oddReal;
        imag[odd] = evenImag - oddImag;

        const nextWeightReal = weightReal * stepReal - weightImag * stepImag;
        weightImag = weightReal * stepImag + weightImag * stepReal;
        weightReal = nextWeightReal;
      }
    }
  }

  if (inverse) {
    for (let i = 0; i < n; i++) {
      real[i] /= n;
      imag[i] /= n;
    }
  }
}

/* A separable 2D transform: FFT across rows, then columns. */
function fft2d(real, imag, width, height, inverse = false) {
  const rowReal = new Float64Array(width);
  const rowImag = new Float64Array(width);

  for (let y = 0; y < height; y++) {
    const offset = y * width;
    for (let x = 0; x < width; x++) {
      rowReal[x] = real[offset + x];
      rowImag[x] = imag[offset + x];
    }
    fft1d(rowReal, rowImag, inverse);
    for (let x = 0; x < width; x++) {
      real[offset + x] = rowReal[x];
      imag[offset + x] = rowImag[x];
    }
  }

  const columnReal = new Float64Array(height);
  const columnImag = new Float64Array(height);
  for (let x = 0; x < width; x++) {
    for (let y = 0; y < height; y++) {
      const index = y * width + x;
      columnReal[y] = real[index];
      columnImag[y] = imag[index];
    }
    fft1d(columnReal, columnImag, inverse);
    for (let y = 0; y < height; y++) {
      const index = y * width + x;
      real[index] = columnReal[y];
      imag[index] = columnImag[y];
    }
  }
}

function signedFrequency(index, length) {
  return index <= Math.floor(length / 2) ? index : index - length;
}

/* Sort frequency bins from lowest to highest radial spatial frequency. */
function buildFrequencyOrder(width, height) {
  const order = new Array(width * height);
  let at = 0;
  for (let y = 0; y < height; y++) {
    const fy = signedFrequency(y, height) / height;
    for (let x = 0; x < width; x++) {
      const fx = signedFrequency(x, width) / width;
      order[at++] = { index: y * width + x, score: fx * fx + fy * fy };
    }
  }
  order.sort((a, b) => a.score - b.score);
  return order;
}

function forwardTransformChannels(imageData, width, height) {
  const pixels = imageData.data;
  const spectra = [];
  const pixelCount = width * height;

  for (let channel = 0; channel < 3; channel++) {
    const real = new Float64Array(pixelCount);
    const imag = new Float64Array(pixelCount);
    for (let i = 0; i < pixelCount; i++) {
      real[i] = pixels[i * 4 + channel];
    }
    fft2d(real, imag, width, height, false);
    spectra.push({ real, imag });
  }
  return spectra;
}

function sliderToRequestedTerms(sliderValue) {
  // Quadratic mapping gives the lower-frequency, blurrier range more slider room.
  const progress = Number(sliderValue) / SLIDER_STEPS;
  return Math.max(1, Math.min(totalTerms, Math.round(1 + progress * progress * (totalTerms - 1))));
}

function keepFrequencyCount(requestedTerms) {
  const threshold = orderedFrequencies[requestedTerms - 1].score;
  let retained = 0;
  while (retained < totalTerms && orderedFrequencies[retained].score <= threshold) retained++;
  return { threshold, retained };
}

function reconstruct(termCount) {
  const { threshold, retained } = keepFrequencyCount(termCount);
  const output = resultCanvas.getContext('2d').createImageData(gridWidth, gridHeight);
  const outputPixels = output.data;
  const retainedMaskBoundary = retained;

  for (let channel = 0; channel < 3; channel++) {
    const real = new Float64Array(channelSpectra[channel].real);
    const imag = new Float64Array(channelSpectra[channel].imag);

    // The sorted list starts with low frequencies; zero all omitted coefficients.
    for (let i = retainedMaskBoundary; i < totalTerms; i++) {
      const index = orderedFrequencies[i].index;
      real[index] = 0;
      imag[index] = 0;
    }

    fft2d(real, imag, gridWidth, gridHeight, true);
    for (let i = 0; i < totalTerms; i++) {
      outputPixels[i * 4 + channel] = Math.max(0, Math.min(255, Math.round(real[i])));
    }
  }

  for (let i = 0; i < totalTerms; i++) outputPixels[i * 4 + 3] = 255;
  resultCanvas.getContext('2d').putImageData(output, 0, 0);

  termsValue.textContent = retained.toLocaleString();
  termsTotal.textContent = `of ${totalTerms.toLocaleString()} coefficients`;
  termsPercent.textContent = `${(retained / totalTerms * 100).toFixed(retained / totalTerms < 0.1 ? 2 : 1)}% of frequency grid retained`;
  renderCaption.textContent = retained === totalTerms
    ? 'All coefficients retained: the sampled image is reconstructed.'
    : `${(totalTerms - retained).toLocaleString()} higher-frequency coefficients omitted.`;
}

function requestRender() {
  if (!isReady || renderPending) return;
  renderPending = true;
  requestAnimationFrame(() => {
    renderPending = false;
    try {
      reconstruct(sliderToRequestedTerms(termsSlider.value));
    } catch (error) {
      console.error(error);
      setStatus('Reconstruction failed. Try a smaller image or a modern browser.', true);
    }
  });
}

function setCanvasDimensions(canvas, width, height) {
  canvas.width = width;
  canvas.height = height;
  canvas.style.aspectRatio = `${width} / ${height}`;
}

function initializeFromImage(image) {
  const grid = nearestGridSize(image.naturalWidth / image.naturalHeight);
  gridWidth = grid.width;
  gridHeight = grid.height;
  totalTerms = gridWidth * gridHeight;

  const { context } = makeContainCanvas(image, gridWidth, gridHeight);
  const sourceData = context.getImageData(0, 0, gridWidth, gridHeight);

  setCanvasDimensions(originalCanvas, gridWidth, gridHeight);
  setCanvasDimensions(resultCanvas, gridWidth, gridHeight);
  originalCanvas.getContext('2d').putImageData(sourceData, 0, 0);

  // Three channels are transformed independently. Alpha is kept fully opaque.
  channelSpectra = forwardTransformChannels(sourceData, gridWidth, gridHeight);
  orderedFrequencies = buildFrequencyOrder(gridWidth, gridHeight);
  isReady = true;

  originalPlaceholder.classList.add('hidden');
  resultPlaceholder.classList.add('hidden');
  termsSlider.disabled = false;
  resetButton.disabled = false;
  termsSlider.max = String(SLIDER_STEPS);
  gridInfo.textContent = `Grid: ${gridWidth} × ${gridHeight}`;
  setStatus(`Loaded ${IMAGE_SRC}. Move the slider to change how many Fourier coefficients are retained.`);

  // Start with a low, but visible, level of detail.
  termsSlider.value = '240';
  requestRender();
}

termsSlider.addEventListener('input', requestRender);
resetButton.addEventListener('click', () => {
  termsSlider.value = String(SLIDER_STEPS);
  requestRender();
});

const sourceImage = new Image();
sourceImage.onload = () => {
  try {
    initializeFromImage(sourceImage);
  } catch (error) {
    console.error(error);
    setStatus('Could not process this image. Use a normal JPG or PNG image.', true);
    originalPlaceholder.textContent = 'Could not process this image.';
    resultPlaceholder.textContent = 'Reconstruction unavailable.';
  }
};
sourceImage.onerror = () => {
  const message = `Image not found: ${IMAGE_SRC}. Put your image in the project root, then update IMAGE_SRC in script.js.`;
  setStatus(message, true);
  originalPlaceholder.textContent = 'Image not found. Update IMAGE_SRC in script.js.';
  resultPlaceholder.textContent = 'Waiting for a valid source image.';
};
sourceImage.src = IMAGE_SRC;
